import { useState } from "react";
import Navbar from "@/components/Navbar";
import ChatBubble from "@/components/ChatBubble";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Video, Send, Smile, Music, Film, Utensils, Copy } from "lucide-react";

const Detect = () => {
  const [messages, setMessages] = useState([
    { text: "Halo! Saya AI Assistant. Bagaimana perasaan Anda hari ini?", isUser: false },
  ]);
  const [inputMessage, setInputMessage] = useState("");

  const handleSendMessage = () => {
    if (inputMessage.trim()) {
      setMessages([...messages, { text: inputMessage, isUser: true }]);
      setInputMessage("");
      
      // Simulate AI response
      setTimeout(() => {
        setMessages(prev => [...prev, {
          text: "Terima kasih atas sharing-nya! Saya di sini untuk membantu Anda.",
          isUser: false
        }]);
      }, 1000);
    }
  };

  const suggestions = [
    "Rekomendasi Film",
    "Tips Mood Booster",
    "Musik Relaksasi",
    "Cerita Motivasi",
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold text-primary text-center mb-8">
          Kenali Emosimu Hari Ini
        </h1>
        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          {/* Left Column - Video Feed & Detection */}
          <div className="space-y-6">
            {/* Video Feed */}
            <div className="bg-card rounded-xl p-6 border border-border shadow-md">
              <div className="aspect-video bg-muted rounded-lg flex items-center justify-center mb-4">
                <Video className="w-16 h-16 text-muted-foreground" />
              </div>
              <Button className="w-full bg-secondary hover:bg-secondary/90 font-medium">
                Detect
              </Button>
            </div>

            {/* Detection Result */}
            <div className="bg-card rounded-xl p-6 border border-border shadow-md">
              <div className="flex items-center justify-center gap-4">
                <Smile className="w-12 h-12 text-emotion-happy" />
                <div>
                  <h3 className="text-2xl font-bold text-primary">Happiness</h3>
                  <p className="text-muted-foreground">Confidence: 90.0%</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Chat Bot */}
          <div className="bg-card rounded-xl p-6 border border-border shadow-md">
            <div className="text-center mb-6">
              <h2 className="text-2xl font-bold text-primary">Chat Bot AI</h2>
              <p className="text-sm text-muted-foreground">Curahan Hatimu</p>
            </div>

            {/* Chat Messages */}
            <div className="h-[400px] overflow-y-auto mb-4 space-y-4">
              {messages.map((msg, index) => (
                <ChatBubble key={index} message={msg.text} isUser={msg.isUser} />
              ))}
            </div>

            {/* Input */}
            <div className="flex gap-2">
              <Input
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder="Ketik pesan..."
                className="flex-1"
              />
              <Button onClick={() => {}} variant="ghost" size="icon">
                <Copy className="w-5 h-5" />
              </Button>
              <Button onClick={handleSendMessage} className="bg-secondary hover:bg-secondary/90">
                Kirim
              </Button>
            </div>
          </div>
        </div>

        {/* Recommendations Section */}
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-6">
            <h2 className="text-3xl font-bold text-primary mb-2">
              Rekomendasi Berbasis Emosi
            </h2>
            <p className="text-muted-foreground">
              Dapatkan saran personal untuk memperbaiki suasana hati atau merayakannya!
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {/* Music Card */}
            <div className="bg-card rounded-xl p-8 border border-border shadow-md hover:shadow-lg transition-shadow text-center">
              <div className="w-16 h-16 bg-[#1DB954] rounded-full flex items-center justify-center mx-auto mb-4">
                <Music className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-foreground">Musik</h3>
            </div>

            {/* Film Card */}
            <div className="bg-card rounded-xl p-8 border border-border shadow-md hover:shadow-lg transition-shadow text-center">
              <div className="w-16 h-16 bg-[#E50914] rounded-full flex items-center justify-center mx-auto mb-4">
                <Film className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-foreground">Film</h3>
            </div>

            {/* Food Card */}
            <div className="bg-card rounded-xl p-8 border border-border shadow-md hover:shadow-lg transition-shadow text-center">
              <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                <Utensils className="w-8 h-8 text-foreground" />
              </div>
              <h3 className="text-xl font-bold text-foreground">Makanan</h3>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Detect;
