import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { LogIn } from "lucide-react";

const AdminLogin = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Simple validation for demo
    if (email && password) {
      navigate("/admin/dashboard");
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar variant="admin" />
      <main className="container mx-auto px-4 py-16">
        <div className="max-w-md mx-auto">
          <div className="bg-card rounded-2xl shadow-xl border border-border p-8 space-y-8">
            <div className="text-center space-y-2">
              <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <LogIn className="w-8 h-8 text-primary-foreground" />
              </div>
              <h1 className="text-3xl font-bold text-primary">Akses Dashboard</h1>
              <p className="text-muted-foreground">Login untuk mengakses admin dashboard</p>
            </div>

            <form onSubmit={handleLogin} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-foreground font-medium">Masukkan Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="admin@gmail.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="h-12"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-foreground font-medium">Masukkan Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="h-12"
                />
              </div>

              <div className="flex items-center justify-between text-sm">
                <span className="text-foreground">
                  Belum Punya Akun?{" "}
                  <button type="button" className="text-secondary hover:underline font-medium">
                    Daftar
                  </button>
                </span>
                <button type="button" className="text-secondary hover:underline font-medium">
                  Lupa Password?
                </button>
              </div>

              <Button 
                type="submit" 
                className="w-full h-12 bg-secondary hover:bg-secondary/90 text-lg font-medium"
              >
                Login
              </Button>
            </form>
          </div>
        </div>
      </main>
    </div>
  );
};

export default AdminLogin;
