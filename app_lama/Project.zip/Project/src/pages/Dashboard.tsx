import Navbar from "@/components/Navbar";
import StatCard from "@/components/StatCard";
import { Users, Smile, TrendingUp, Calendar } from "lucide-react";

const Dashboard = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar variant="admin" />
      <main className="container mx-auto px-4 py-8">
        <div className="space-y-8">
          <div>
            <h1 className="text-4xl font-bold text-primary mb-2">Analisis Emosi</h1>
          </div>

          {/* Statistics Cards */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <StatCard
              title="Total Sesi Deteksi"
              value="245"
              icon={Users}
              trend="+12.5% dari minggu lalu"
              color="primary"
            />
            <StatCard
              title="Emosi Dominan"
              value="Happiness"
              icon={Smile}
              trend="40% dari keseluruhan deteksi"
              color="emotion-happy"
            />
            <StatCard
              title="Rata-Rata Emosi Negatif"
              value="15%"
              icon={TrendingUp}
              trend="-2.3% dari minggu lalu (Tren positif!)"
              color="emotion-sad"
            />
            <StatCard
              title="Rata-Rata Sesi per Pengguna"
              value="4.8"
              icon={Calendar}
              trend="+3.1% dari minggu lalu (Tren positif!)"
              color="secondary"
            />
          </div>

          {/* Charts Section */}
          <div className="grid lg:grid-cols-2 gap-6">
            {/* Emotion Distribution Chart */}
            <div className="bg-card rounded-xl shadow-lg border border-border p-6">
              <h3 className="text-2xl font-bold text-primary mb-6">Distribusi Emosi</h3>
              <div className="aspect-square bg-muted rounded-lg flex items-center justify-center">
                <div className="text-center space-y-2">
                  <div className="w-48 h-48 bg-gradient-to-br from-emotion-happy via-emotion-sad to-emotion-angry rounded-full mx-auto opacity-20"></div>
                  <p className="text-muted-foreground mt-4">[Donut Chart Placeholder]</p>
                  <p className="text-sm text-muted-foreground">Visualisasi distribusi 7 emosi</p>
                </div>
              </div>
            </div>

            {/* Trend Chart */}
            <div className="bg-card rounded-xl shadow-lg border border-border p-6">
              <h3 className="text-2xl font-bold text-primary mb-6">Tren Top Emosi</h3>
              <div className="aspect-square bg-muted rounded-lg flex items-center justify-center">
                <div className="text-center space-y-2">
                  <svg className="w-full h-48 px-8" viewBox="0 0 400 200">
                    <path
                      d="M 0 150 Q 100 50 200 100 T 400 50"
                      fill="none"
                      stroke="hsl(217 89% 61%)"
                      strokeWidth="3"
                      opacity="0.3"
                    />
                  </svg>
                  <p className="text-muted-foreground">[Line Chart Placeholder]</p>
                  <p className="text-sm text-muted-foreground">Tren deteksi dalam 7 hari terakhir</p>
                </div>
              </div>
            </div>
          </div>

          {/* Recent Activity */}
          <div className="bg-card rounded-xl shadow-lg border border-border p-6">
            <h3 className="text-2xl font-bold text-primary mb-4">Aktivitas Terkini</h3>
            <div className="space-y-4">
              {[
                { time: "10:30 AM", emotion: "Happy", confidence: "92%" },
                { time: "09:45 AM", emotion: "Neutral", confidence: "85%" },
                { time: "09:15 AM", emotion: "Sad", confidence: "78%" },
              ].map((activity, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-4 bg-muted rounded-lg"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-2 h-2 bg-secondary rounded-full"></div>
                    <div>
                      <p className="font-medium text-foreground">{activity.emotion}</p>
                      <p className="text-sm text-muted-foreground">{activity.time}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-secondary">{activity.confidence}</p>
                    <p className="text-xs text-muted-foreground">Confidence</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
