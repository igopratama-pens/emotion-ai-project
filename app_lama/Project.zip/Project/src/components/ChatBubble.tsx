interface ChatBubbleProps {
  message: string;
  isUser: boolean;
}

const ChatBubble = ({ message, isUser }: ChatBubbleProps) => {
  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"} mb-4`}>
      <div
        className={`max-w-[70%] px-4 py-3 rounded-2xl ${
          isUser
            ? "bg-secondary text-secondary-foreground rounded-br-sm"
            : "bg-muted text-foreground rounded-bl-sm"
        } shadow-sm`}
      >
        <p className="text-sm">{message}</p>
      </div>
    </div>
  );
};

export default ChatBubble;
