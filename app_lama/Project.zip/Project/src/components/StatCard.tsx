import { LucideIcon } from "lucide-react";

interface StatCardProps {
  title: string;
  value: string;
  icon: LucideIcon;
  trend?: string;
  color?: "primary" | "secondary" | "emotion-happy" | "emotion-sad";
}

const StatCard = ({ title, value, icon: Icon, trend, color = "secondary" }: StatCardProps) => {
  const colorClasses = {
    primary: "bg-primary text-primary-foreground",
    secondary: "bg-secondary text-secondary-foreground",
    "emotion-happy": "bg-emotion-happy text-foreground",
    "emotion-sad": "bg-emotion-sad text-primary-foreground",
  };

  return (
    <div className="bg-card rounded-xl p-6 shadow-md hover:shadow-lg transition-shadow border border-border">
      <div className="flex items-start justify-between mb-4">
        <div className={`w-12 h-12 ${colorClasses[color]} rounded-lg flex items-center justify-center`}>
          <Icon className="w-6 h-6" />
        </div>
        {trend && (
          <span className="text-sm text-muted-foreground">{trend}</span>
        )}
      </div>
      <h3 className="text-sm font-medium text-muted-foreground mb-2">{title}</h3>
      <p className="text-3xl font-bold text-foreground">{value}</p>
    </div>
  );
};

export default StatCard;
